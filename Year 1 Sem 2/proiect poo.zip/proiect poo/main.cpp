#include <iostream>
#include <fstream>
#include <queue>
using namespace std;

class Nod
{
    int val;
    Nod *left, *right;
public:
    Nod (int k = 0, Nod *stanga = NULL, Nod *dreapta = NULL)
    {
        val = k;
        left = stanga;
        right = dreapta;
    }
    Nod (Nod &k)
    {
        val = k.val;
        left = k.left;
        right = k.right;
    }
    Nod operator=(Nod k)
    {
        val = k.val;
        left = k.left;
        right = k.right;
    }
    friend istream& operator>>(istream &in, Nod &k)
    {
        in >> k.val;
        return in;
    }
    friend ostream& operator<<(ostream &out, Nod &k)
    {
        out << k.val << '\n';
        return out;
    }
    ~Nod ()
    {
        val = 0;
        left = right = NULL;
    }
    int getVal ()
    {
        return val;
    }
    void setVal (int valoare)
    {
        val = valoare;
    }
    Nod* getLeft()
    {
        return left;
    }
    void setLeft (Nod* stanga)
    {
        left = stanga;
    }
    Nod* getRight()
    {
        return right;
    }
    void setRight (Nod* dreapta)
    {
        right = dreapta ;
    }
};

enum COLOR { RED, BLACK };

class Node : Nod
{
    COLOR color;
    Node *left, *right, *parent;
    int val = getVal();
public:
    Node(int k = 0, Node* stanga = NULL, Node* dreapta = NULL, Node* parinte = NULL)
    {
        parent = parinte;              // Node is created during insertion
        left = stanga;                 // Node is red at insertion
        right = dreapta;
        val = k;
        color = RED;
    }
    Node (Node &k)
    {
        val = k.val;
        left = k.left;
        right = k.right;
        parent = k.parent;
        color = k.color;
    }
    Node operator=(Node k)
    {
        val = k.val;
        left = k.left;
        right = k.right;
        parent = k.parent;
        color = k.color;
    }
    friend istream& operator>>(istream &in, Node &k)
    {
        in >> k.val;
        return in;
    }
    friend ostream& operator<<(ostream &out, Node &k)
    {
        out << k.val << '\n';
        return out;
    }
    int getVal ()
    {
        return val;
    }
    void setVal (int valoare)
    {
        val = valoare;
    }
    Node* getLeft()
    {
        return left;
    }
    void setLeft (Node* stanga)
    {
        left = stanga;
    }
    Node* getRight()
    {
        return right;
    }
    void setRight (Node* dreapta)
    {
        right = dreapta ;
    }
    Node* getParent()
    {
        return parent;
    }
    void setParent(Node *parinte)
    {
        parent = parinte;
    }
    COLOR getColor()
    {
        return color;
    }
    void setColor(COLOR culoare)
    {
        color = culoare;
    }

    Node *uncle()
    {
        if (parent == NULL or parent->parent == NULL)
          return NULL;

        if (parent->isOnLeft())
          return parent->parent->right;
        else
          return parent->parent->left;
    }

    bool isOnLeft() { return this == parent->left; }

    Node *sibling()
    {
        if (parent == NULL)
            return NULL;

        if (isOnLeft())
            return parent->right;

        return parent->left;
    }

    void moveDown(Node *nParent)
    {
        if (parent != NULL) {
            if (isOnLeft())
                parent->left = nParent;
            else
            parent->right = nParent;
        }
        nParent->parent = parent;
        parent = nParent;
    }

    bool hasRedChild()
    {
        return (left != NULL and left->color == RED) or
            (right != NULL and right->color == RED);
    }
};

class Arbore///???
{
    int nr_noduri;
public:
    Arbore(int nrNoduri = 0)
    {
        nr_noduri = nrNoduri;
    }
    virtual int get_depth()
    {
    }
};

class BST : Arbore ///MERGE
{
    Nod *root;

    Nod* insert(int x, Nod* t)
    {
        if(t == NULL)
        {
            t =new Nod(x);
        }
        else if(x < t->getVal())
            t->setLeft(insert(x, t->getLeft()));
        else if(x > t->getVal())
            t->setRight(insert(x, t->getRight()));
        return t;
    }

    Nod* findMin(Nod* t)
    {
        if(t == NULL)
            return NULL;
        else if(t->getLeft() == NULL)
            return t;
        else
            return findMin(t->getLeft());
    }

    Nod* findMax(Nod* t)
    {
        if(t == NULL)
            return NULL;
        else if(t->getRight() == NULL)
            return t;
        else
            return findMax(t->getRight());
    }

    Nod* remove(int x, Nod* t)
    {
        Nod* temp;
        if(t == NULL)
            return NULL;
        else if(x < t->getVal())
            t->setLeft(remove(x, t->getLeft()));
        else if(x > t->getVal())
            t->setRight(remove(x, t->getRight()));
        else if(t->getLeft() && t->getRight())
        {
            temp = findMin(t->getRight());
            t->setVal(temp->getVal());
            t->setRight(remove(t->getVal(), t->getRight()));
        }
        else
        {
            temp = t;
            if(t->getLeft() == NULL)
                t = t->getRight();
            else if(t->getRight() == NULL)
                t = t->getLeft();
            delete temp;
        }

        return t;
    }

    void leaves(Nod* t)
    {
        if(t == NULL)
            return;
        if (t->getLeft() == NULL && t->getRight() == NULL)
            cout << t->getVal() << " ";
        leaves(t->getLeft());
        leaves(t->getRight());
    }

    Nod* makeEmpty(Nod* t)
    {
        if(t == NULL)
            return NULL;
        {
            makeEmpty(t->getLeft());
            makeEmpty(t->getRight());
            delete t;
        }
        return NULL;
    }

    int height (Nod *node)
    {
        if (node == NULL)
            return 0;
        int lDepth = height(node->getLeft());
        int rDepth = height(node->getRight());

        if (lDepth > rDepth)
            return(lDepth+1);
        else
            return(rDepth+1);
    }

public:

    BST()
    {
        root = NULL;
    }

    ~BST()
    {
        root = makeEmpty(root);
    }

    void operator + (int x)
    {
        root = insert (x, root);
    }

    friend istream &operator>> (istream &in, BST &t)
    {
        int n, x;
        in >> n;
        for (int i = 0; i < n; i++)
        {
            in >> x;
            t + x;
        }
    }

    void leaves()
    {
        cout << "Frunzele arborelui sunt : ";
        leaves(root);
        cout << endl;
    }

    void remove(int x)
    {
        root = remove(x, root);
        cout << "Se sterge nodul " << x <<"." << endl << endl;
    }

    int get_depth()
    {
        return height(root);
    }

    void print(ostream &out, Nod *curr)
    {
        if(curr)
        {
            print(out, curr->getLeft());
            out << curr->getVal() << " ";
            print(out, curr->getRight());
        }
    }

    friend ostream & operator<<(ostream &out, BST &t)
    {
        out << "Parcurgerea in inordine a arborelui este : ";
        t.print(out, t.root);
        out << endl << endl;

        return out;
    }

};

class RBTree : Arbore
{
    Node *root;

    void leftRotate(Node *x)
    {
        Node *nParent = x->getRight();

        if (x == root)
            root = nParent;

        x->moveDown(nParent);

        x->setRight(nParent->getLeft());
        if (nParent->getLeft() != NULL)
            nParent->getLeft()->setParent(x);

        nParent->setLeft(x);
    }

    void rightRotate(Node *x)
    {
        Node *nParent = x->getLeft();

        if (x == root)
            root = nParent;

        x->moveDown(nParent);

        x->setLeft(nParent->getRight());
        if (nParent->getRight() != NULL)
            nParent->getRight()->setParent(x);

        nParent->setRight(x);
    }

    void swapColors(Node *x1, Node *x2)
    {
        COLOR temp;
        temp = x1->getColor();
        x1->setColor(x2->getColor());
        x2->setColor(temp);
    }

    void swapValues(Node *u, Node *v)
    {
        int temp;
        temp = u->getVal();
        u->setVal(v->getVal());
        v->setVal(temp);
    }

    void fixRedRed(Node *x)
    {
        if (x == root)
        {
            x->setColor(BLACK);
            return;
        }

        Node *parent = x->getParent(), *grandparent = parent->getParent(), *uncle = x->uncle();

        if (parent->getColor() != BLACK)
        {
            if (uncle != NULL && uncle->getColor() == RED)
            {
                // daca unchiul este rosu, se face recolorare
                parent->setColor(BLACK);
                uncle->setColor(BLACK);
                grandparent->setColor(RED);
                fixRedRed(grandparent);
            }
            else
            {
                // daca unchiul este negru, se fac rotatii
                if (parent->isOnLeft())
                {
                    if (x->isOnLeft())
                        swapColors(parent, grandparent);
                    else
                    {
                        leftRotate(parent);
                        swapColors(x, grandparent);
                    }
                    rightRotate(grandparent);
                }
                else
                {
                    if (x->isOnLeft())
                    {
                        rightRotate(parent);
                        swapColors(x, grandparent);
                    }
                    else
                        swapColors(parent, grandparent);
                    leftRotate(grandparent);
                }
            }
        }
    }

    Node *successor(Node *x)
    {
        Node *temp = x;
        while (temp->getLeft() != NULL)
            temp = temp->getLeft();
        return temp;
    }

    Node *BSTreplace(Node *x)
    {
        if (x->getLeft() != NULL and x->getRight() != NULL)
            return successor(x->getRight());
        if (x->getLeft() == NULL and x->getRight() == NULL)
            return NULL;
        if (x->getLeft() != NULL)
            return x->getLeft();
        else
            return x->getRight();
    }

    void deleteNode(Node *v)
    {
        Node *u = BSTreplace(v);

        bool uvBlack = ((u == NULL or u->getColor() == BLACK) and (v->getColor() == BLACK));
        Node *parent = v->getParent();

        if (u == NULL)
        {
            if (v == root)
            root = NULL;
            else
            {
                if (uvBlack)
                    fixDoubleBlack(v);
                else if (v->sibling() != NULL)
                    v->sibling()->setColor(RED);
                if (v->isOnLeft())
                    parent->setLeft(NULL);
                else
                    parent->setRight(NULL);
            }
            delete v;
            return;
        }

        if (v->getLeft() == NULL or v->getRight() == NULL)
        {
            if (v == root)
            {
                v->setVal(u->getVal());
                v->setLeft(NULL);
                v->setRight(NULL);
                delete u;
            }
            else
            {
                if (v->isOnLeft())
                    parent->setLeft(u);
                else
                    parent->setRight(u);
                delete v;
                u->setParent(parent);
                if (uvBlack)
                    fixDoubleBlack(u);
                else
                    u->setColor(BLACK);
            }
            return;
        }

        swapValues(u, v);
        deleteNode(u);
    }

    void fixDoubleBlack(Node *x)
    {
        if (x == root)
            return;

        Node *sibling = x->sibling(), *parent = x->getParent();
        if (sibling == NULL)
            fixDoubleBlack(parent);
        else
        {
            if (sibling->getColor() == RED)
            {
                parent->setColor(RED);
                sibling->setColor(BLACK);
                if (sibling->isOnLeft())
                    rightRotate(parent);
                else
                    leftRotate(parent);
                fixDoubleBlack(x);
            }
            else
            {
                if (sibling->hasRedChild())
                {
                    if (sibling->getLeft() != NULL and sibling->getLeft()->getColor() == RED)
                    {
                        if (sibling->isOnLeft())
                        {
                            sibling->getLeft()->setColor(sibling->getColor());
                            sibling->setColor(parent->getColor());
                            rightRotate(parent);
                        }
                        else
                        {
                            sibling->getLeft()->setColor(parent->getColor());
                            rightRotate(sibling);
                            leftRotate(parent);
                        }
                    }
                    else
                    {
                        if (sibling->isOnLeft())
                        {
                            sibling->getRight()->setColor(parent->getColor());
                            leftRotate(sibling);
                            rightRotate(parent);
                        }
                        else
                        {
                            sibling->getRight()->setColor(sibling->getColor());
                            sibling->setColor(parent->getColor());
                            leftRotate(parent);
                        }
                    }
                    parent->setColor(BLACK);
                }
                else
                {
                sibling->setColor(RED);
                if (parent->getColor() == BLACK)
                    fixDoubleBlack(parent);
                else
                    parent->setColor(BLACK);
                }
            }
        }
    }

    void InorderRBT(ostream &out, Node *curr)
    {
        if(curr)
        {
            InorderRBT(out, curr->getLeft());
            out << curr->getVal() << " ";
            InorderRBT(out, curr->getRight());
        }
    }

    void OrderRBT(ostream &out, Node *x)
    {
        if (x == NULL)
            return;
        queue<pair <Node*, int>> q;
        Node *curr;
        int inaltimeCurenta = 0;
        q.push({x, inaltimeCurenta});
        out << '\n';
        while (!q.empty())
        {
            curr = q.front().first;
            inaltimeCurenta=q.front().second;
            q.pop();

            out << curr->getVal() << " pe nivelul " << inaltimeCurenta << '\n';

            if (curr->getLeft() != NULL)
                q.push({curr->getLeft(), inaltimeCurenta+1});
            if (curr->getRight() != NULL)
                q.push({curr->getRight(), inaltimeCurenta+1});
        }
    }

    void inaltimea_neagra (Node *t, int &nr)
    {
        if (t == NULL)
            return;
        if (t->getColor() == BLACK)
            nr++;
        inaltimea_neagra(t->getLeft(), nr);
    }

    Node* makeEmpty(Node* t)
    {
        if(t == NULL)
            return NULL;
        {
            makeEmpty(t->getLeft());
            makeEmpty(t->getRight());
            delete t;
        }
        return NULL;
    }

public:

    RBTree() { root = NULL; }
    Node *getRoot() { return root; }

    ~RBTree() { makeEmpty(root); }

    friend istream &operator>> (istream &in, RBTree &t)
    {
        int n, x;
        in >> n;
        for (int i = 0; i < n; i++)
        {
            in >> x;
            t.insert (x);
        }
    }

    friend ostream & operator<<(ostream &out, RBTree &t)
    {
        out << "Parcurgerea in inordine a arborelui este : ";
        t.InorderRBT(out, t.root);
        cout << '\n';
        out << "Parcurgerea pe nivele a arborelui este : ";
        t.OrderRBT(out, t.root);
        out << endl;

        return out;
    }

    Node *search(int n)
    {
        Node *temp = root;
        while (temp != NULL)
        {
            if (n < temp->getVal())
            {
                if (temp->getLeft() == NULL)
                    break;
                else
                    temp = temp->getLeft();
            }
            else if (n == temp->getVal())
                break;
            else
            {
                if (temp->getRight() == NULL)
                    break;
                else
                    temp = temp->getRight();
            }
        }

    return temp;
    }

    void insert(int n)
    {
        Node *newNode = new Node(n);
        if (root == NULL)
        {
            newNode->setColor(BLACK);
            root = newNode;
        }
        else
        {
            Node *temp = search(n);

            if (temp->getVal() == n)
                return;
            newNode->setParent(temp);

            if (n < temp->getVal())
                temp->setLeft(newNode);
            else
                temp->setRight(newNode);

            fixRedRed(newNode);
        }
    }

    void deleteByVal(int n)
    {
        if (root == NULL)
            return;

        Node *v = search(n), *u;

        if (v->getVal() != n)
        {
            cout << "No node found to delete with value:" << n << endl;
            return;
        }

        deleteNode(v);
    }

    int get_depth()
    {
        int nr = 0;
        inaltimea_neagra(getRoot(), nr);
        return nr;
    }

};

int main()
{
    RBTree tree;
    ifstream fin ("date.in");
    fin >> tree;

    cout << tree;

    cout << "Se sterge 18" << '\n';
    tree.deleteByVal(18);

    cout << tree;

    cout << "Inaltimea neagra a arborelui este: " << tree.get_depth();



    return 0;
}
